# Evaluacion-m2

Aprendiendo a usar HTML CSS y Javascript

La santisima trinidad del diseño de la Wide Web World

Menu de un restaurant ficticio que incluye funcionalidad basica de HTML

Evaluacion del modulo 2

Hasta ahora

Implementacion HTML CSS

Implementacion Flex

Implementacion Bootstrap

Implementacion Bootstrap v2

Implementacion Javascript

Implementacion Modal

Implementacion JQuery

Implementacion Modal 2

sitio https://jioh19.github.io/Evaluacion-m2/ en linea
